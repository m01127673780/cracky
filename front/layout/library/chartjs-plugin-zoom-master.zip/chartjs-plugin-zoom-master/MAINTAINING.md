# Maintaining

## Release Process

Chart.js relies on [Travis CI](https://travis-ci.org/) to automate the library [releases](https://github.com/chartjs/chartjs-plugin-zoom/releases).

### Releasing a New Version

1. draft release notes on [GitHub](https://github.com/chartjs/chartjs-plugin-zoom/releases/new) for the upcoming tag
1. update `master` `package.json` version using [semver](https://semver.org/) semantic
1. merge `master` into the `release` branch
1. follow the build process on [Travis CI](https://travis-ci.org/chartjs/chartjs-plugin-zoom)

> **Note:** if `master` is merged in `release` with a `package.json` version that already exists, the tag creation fails and the release process is aborted.

### Automated Tasks

Merging into the `release` branch kicks off the automated release process:

* build of the `dist/*.js` files
* `dist/*.js` are copied to the root directory
* `bower.json` is generated from `package.json`
* `dist/*.js` and `bower.json` are added to a detached branch
* a tag is created from the `package.json` version
* tag (with dist files) is pushed to GitHub

Creation of this tag triggers a new build:

* `chartjs-plugin-zoom.zip` package is generated, containing dist files and examples
* `dist/*.js` and `chartjs-plugin-zoom.zip` are attached to the GitHub release (downloads)
* a new npm package is published on [npmjs](https://www.npmjs.com/package/chartjs-plugin-zoom)

Finally, [cdnjs](https://cdnjs.com/libraries/chartjs-plugin-zoom) is automatically updated from the npm release.
