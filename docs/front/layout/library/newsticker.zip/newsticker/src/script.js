$(document).ready(function(){		
	$('#newsTicker15').breakingNews({
		position : 'fixed-top',
		borderWidth: 3,
		height: 45,
		themeColor: '#ce2525'
	});
});