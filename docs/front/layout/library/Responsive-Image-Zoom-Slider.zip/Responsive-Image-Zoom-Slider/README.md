jquery image slider
===================

### This is a fully responsive image slider

You can edit the following lines:

**js/image-slider.js**

* line 4: provide an array of image sources
* line 7: change the slider interval in milliseconds

**css/image-slider.css:**

* line 50: set the animation interval same 
to one set in js/image-slider.js

